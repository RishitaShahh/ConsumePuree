document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault();
    
    // Get input values
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let message = document.getElementById("message").value;

    // Simple validation
    if (name === "" || email === "" || message === "") {
        document.getElementById("responseMessage").textContent = "Please fill all fields!";
        document.getElementById("responseMessage").style.color = "red";
        return;
    }

    // Simulate form submission
    document.getElementById("responseMessage").textContent = "Message sent successfully!";
    document.getElementById("responseMessage").style.color = "green";

    // Clear form
    document.getElementById("contactForm").reset();
});
