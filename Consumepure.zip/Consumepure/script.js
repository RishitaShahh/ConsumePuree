// Function to handle medicine search
function searchMedicine() {
    let query = document.getElementById("searchBox").value.trim();

    if (query === "") {
        alert("Please enter a medicine name.");
        return;
    }

    // Simulate search results (Replace this with actual API or database connection)
    let medicines = {
        "Paracetamol": "Used for pain relief and fever reduction.",
        "Ibuprofen": "Helps reduce inflammation and pain.",
        "Aspirin": "Used for pain relief, fever, and heart conditions."
    };

    let resultDiv = document.getElementById("searchResults");
    resultDiv.innerHTML = ""; // Clear previous results

    if (medicines[query]) {
        resultDiv.innerHTML = `<p><strong>${query}:</strong> ${medicines[query]}</p>`;
    } else {
        resultDiv.innerHTML = `<p style="color: red;">No information found for "${query}".</p>`;
    }
}

// Add animations on page load
document.addEventListener("DOMContentLoaded", function () {
    let elements = document.querySelectorAll("header, #search, #features, footer");

    elements.forEach((el, index) => {
        setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
        }, 200 * index);
    });
});

// Add enter key support for search
document.getElementById("searchBox").addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        searchMedicine();
    }
});
