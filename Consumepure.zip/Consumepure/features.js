document.addEventListener("DOMContentLoaded", function () {
    console.log("Features page loaded successfully!");
});
